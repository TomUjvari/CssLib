# CssLib
My personal library of reusable CSS classes.  
Check the **examples** folder to see HTML examples.

## What each file does
-  **main.css** : Contains positioning and basic styling classes.
-  **navbar-horizontal.css** : Horizontal navbar at the top center of the screen.
-  **navbar-vertical.css** : Vertical navbar at the middle left of the screen.